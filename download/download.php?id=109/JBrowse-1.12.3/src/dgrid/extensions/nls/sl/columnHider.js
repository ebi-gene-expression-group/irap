define("dgrid/extensions/nls/sl/columnHider", {
	popupTriggerLabel: 'Pokaži ali skrij stolpce',
	popupLabel: 'Pokaži ali skrij stolpce'
});
