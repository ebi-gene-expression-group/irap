define("dijit/nls/bs/loading", {      
//begin v1.x content
	loadingState: "Učitavanje...",
	errorState: "Izvinite, došlo je do greške"
//end v1.x content
});

