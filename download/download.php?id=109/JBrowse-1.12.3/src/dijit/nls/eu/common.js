define("dijit/nls/eu/common", {      
//begin v1.x content
	buttonOk: "Ados",
	buttonCancel: "Utzi",
	buttonSave: "Gorde",
	itemClose: "Itxi"
//end v1.x content
});

