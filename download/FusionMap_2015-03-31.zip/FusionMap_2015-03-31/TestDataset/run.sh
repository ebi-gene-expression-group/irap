### input whole paired end fastq files for fusion detection 
/IData/App/mono/mono-2.10.9/bin/mono /IData/App/FusionMap/FusionMap_2015-03-31/bin/FusionMap.exe --semap /IData/OmicsoftFolders/OmicsoftSGE Human.B37.3 RefGene /IData/App/FusionMap/FusionMap_2015-03-31/TestDataset/01.FusionSE.Input.Fastq.Linux.config > /IData/App/FusionMap/FusionMap_2015-03-31/TestDataset/output/01_FusionSE.Input.Fastq.Linux.log

### input whole paired end fastq files for fusion detection (more analysis options)
/IData/App/mono/mono-2.10.9/bin/mono /IData/App/FusionMap/FusionMap_2015-03-31/bin/FusionMap.exe --semap /IData/OmicsoftFolders/OmicsoftSGE Human.B37.3 RefGene /IData/App/FusionMap/FusionMap_2015-03-31/TestDataset/02.FusionSE.Input.Fastq.Linux.AllOptions.config > /IData/App/FusionMap/FusionMap_2015-03-31/TestDataset/output/02_FusionSE.Input.Fastq.Linux.AllOptions.log

### input BAM file for fusion detection 
/IData/App/mono/mono-2.10.9/bin/mono /IData/App/FusionMap/FusionMap_2015-03-31/bin/FusionMap.exe --semap /IData/OmicsoftFolders/OmicsoftSGE Human.B37.3 RefGene /IData/App/FusionMap/FusionMap_2015-03-31/TestDataset/03.FusionSE.Input.BAM.Linux.config > /IData/App/FusionMap/FusionMap_2015-03-31/TestDataset/output/03_FusionSE.Input.BAM.Linux.log

cd /IData/App/FusionMap/FusionMap_2015-03-31/TestDataset/output
mv DatasetP2_SimulatedReads.FusionReads.bam DatasetP2_SimulatedReads.FusionReads.SE.bam

### input BAM file for fusion detection (based on discordant read pairs only)
/IData/App/mono/mono-2.10.9/bin/mono /IData/App/FusionMap/FusionMap_2015-03-31/bin/FusionMap.exe --pereport /IData/OmicsoftFolders/OmicsoftSGE Human.B37.3 RefGene /IData/App/FusionMap/FusionMap_2015-03-31/TestDataset/04.FusionPE.Linux.config > /IData/App/FusionMap/FusionMap_2015-03-31/TestDataset/output/04_FusionPE.Linux.log

### because fusionmap output fusion semap and pereport reads BAM files in the same file name: *.FusionReads.bam
cd /IData/App/FusionMap/FusionMap_2015-03-31/TestDataset/output
mv DatasetP2_SimulatedReads.FusionReads.bam DatasetP2_SimulatedReads.FusionReads.PE.bam

