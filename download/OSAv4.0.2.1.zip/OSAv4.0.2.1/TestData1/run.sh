mono /test/OSA/bin/osa.exe --alignrna /test/ Human.B37 RefGene /test/OSA/TestData1/secontrol_linux.ini > /test/OSA/TestData1/output_linux/secontrol_linux.log





